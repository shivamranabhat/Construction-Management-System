<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'image',
        'password',
        'type',
        'company_id',
        'slug',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
    
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class, 'role_users');
    }

    public function projects()
    {
        return $this->belongsToMany(Project::class, 'project_user')
                    ->withPivot('company_id');
    }

    public function assignedProjects()
    {
        return $this->projects();
    }

    
    public function hasPermission($module, $action)
    {
        return $this->roles()
            ->whereHas('permissions', function ($query) use ($module, $action) {
                $query->whereHas('module', function ($q) use ($module) {
                    $q->where('slug', $module);
                })->where('slug', $action);
            })
            ->exists();
    }

    public function stockMovements()
    {
        return $this->hasMany(StockMovement::class, 'entered_by');
    }

    public function purchases()
    {
        return $this->hasMany(Purchase::class, 'entered_by');
    }

}
