<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\Scopes\CompanyScope;

class Worker extends Model
{
    protected static function booted()
    {
        static::addGlobalScope(new CompanyScope);
        static::creating(function ($worker) {
            $worker->slug = $worker->generateUniqueSlug();
        });
    }
    protected $fillable = [
        'name',
        'phone',
        'role',
        'company_id',
        'slug',
    ];


    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function generateUniqueSlug(): string
    {
        $slug = Str::slug($this->name);
        $count = static::where('slug', 'like', $slug . '%')->count();
        return $count ? $slug . '-' . ($count + 1) : $slug;
    }

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function attendances()
    {
        return $this->hasMany(Attendance::class);
    }
}
