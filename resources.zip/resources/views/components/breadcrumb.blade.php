<div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb" wire:ignore>
    <div class="my-auto">
        <h5 class="page-title fs-21 mb-1" style="text-transform: capitalize">{{request()->segment(1)}}</h5>
        <nav>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="javascript:void(0);" style="text-transform: capitalize">{{request()->segment(1)}}</a></li>
                <li class="breadcrumb-item active" aria-current="page" style="text-transform: capitalize">{{request()->segment(2)=='' ? 'Index' : str_replace('-',' ', request()->segment(2))}}</li>
            </ol>
        </nav>
    </div>

</div>