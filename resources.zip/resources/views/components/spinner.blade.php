<div class="spinner-border spinner-border-sm" wire:loading.delay role="status">
  <span class="visually-hidden">Loading...</span>
</div>