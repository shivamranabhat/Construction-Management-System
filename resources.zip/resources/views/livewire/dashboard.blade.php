<div class="col-xl-12">
    <div class="card custom-card">
        <div class="card-header justify-content-between">
            <div class="card-title">Dashboard</div>
        </div>  
        <div class="card-body">
            <h5>Welcome, {{ Auth::user()->name }}!</h5>
            <p>This is your dashboard.</p>
        </div>
    </div>
</div>